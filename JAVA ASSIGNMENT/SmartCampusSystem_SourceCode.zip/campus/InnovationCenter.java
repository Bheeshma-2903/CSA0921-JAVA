package campus;

public class InnovationCenter extends Facility {
    public InnovationCenter(String facilityId, String name, int capacity) {
        super(facilityId, name, capacity);
    }

    @Override
    public String getFeatures() {
        return "3D printers, IoT kits, prototyping benches";
    }

    @Override
    public double getHourlyRate() {
        return 300.0;
    }
}
