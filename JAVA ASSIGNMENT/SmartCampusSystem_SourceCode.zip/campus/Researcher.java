package campus;

/** Researcher user – highest booking priority (project deadlines). */
public class Researcher extends User {
    public Researcher(String userId, String name, String department) {
        super(userId, name, department);
    }

    @Override
    public String getRole() {
        return "Researcher";
    }

    @Override
    public int getBookingPriority() {
        return 3;
    }
}
