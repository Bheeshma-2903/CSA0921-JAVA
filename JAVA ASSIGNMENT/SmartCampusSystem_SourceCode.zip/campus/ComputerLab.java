package campus;

public class ComputerLab extends Facility {
    public ComputerLab(String facilityId, String name, int capacity) {
        super(facilityId, name, capacity);
    }

    @Override
    public String getFeatures() {
        return "60 workstations, LAN, projector";
    }

    @Override
    public double getHourlyRate() {
        return 150.0;
    }
}
