package campus;

/** Faculty user – medium booking priority. */
public class Faculty extends User {
    public Faculty(String userId, String name, String department) {
        super(userId, name, department);
    }

    @Override
    public String getRole() {
        return "Faculty";
    }

    @Override
    public int getBookingPriority() {
        return 2;
    }
}
