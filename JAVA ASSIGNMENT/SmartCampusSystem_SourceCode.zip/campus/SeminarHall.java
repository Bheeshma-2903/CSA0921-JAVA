package campus;

public class SeminarHall extends Facility {
    public SeminarHall(String facilityId, String name, int capacity) {
        super(facilityId, name, capacity);
    }

    @Override
    public String getFeatures() {
        return "Podium, PA system, tiered seating";
    }

    @Override
    public double getHourlyRate() {
        return 200.0;
    }
}
