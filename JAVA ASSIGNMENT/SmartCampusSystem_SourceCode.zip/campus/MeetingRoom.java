package campus;

public class MeetingRoom extends Facility {
    public MeetingRoom(String facilityId, String name, int capacity) {
        super(facilityId, name, capacity);
    }

    @Override
    public String getFeatures() {
        return "Conference table, video-conferencing";
    }

    @Override
    public double getHourlyRate() {
        return 100.0;
    }
}
