package campus;

import java.util.*;

/**
 * Smart Campus Resource Allocation and Facility Management System
 * Menu-driven console application.
 */
public class SmartCampusApp {

    private static final BookingManager manager = new BookingManager();
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        seedDemoData();
        boolean running = true;
        while (running) {
            printMenu();
            String choice = sc.nextLine().trim();
            try {
                switch (choice) {
                    case "1": listFacilities(); break;
                    case "2": listUsers(); break;
                    case "3": bookFacilityMenu(); break;
                    case "4": cancelBookingMenu(); break;
                    case "5": modifyBookingMenu(); break;
                    case "6": viewAllBookings(); break;
                    case "7": utilizationReport(); break;
                    case "8": userActivityReport(); break;
                    case "9": runConcurrentDemo(); break;
                    case "0": running = false; System.out.println("Exiting. Thank you!"); break;
                    default: System.out.println("Invalid option, try again.");
                }
            } catch (Exception e) {
                // Top-level guard so a single bad input never crashes the menu loop.
                System.out.println("Error: " + e.getMessage());
            }
        }
        sc.close();
    }

    private static void printMenu() {
        System.out.println("\n===== SMART CAMPUS RESOURCE ALLOCATION SYSTEM =====");
        System.out.println("1. View Facilities");
        System.out.println("2. View Registered Users");
        System.out.println("3. Book a Facility");
        System.out.println("4. Cancel a Booking");
        System.out.println("5. Modify a Booking");
        System.out.println("6. View All Bookings");
        System.out.println("7. Facility Utilization Report");
        System.out.println("8. User Activity Report");
        System.out.println("9. Run Concurrent Booking Demo (Multithreading)");
        System.out.println("0. Exit");
        System.out.print("Enter choice: ");
    }

    private static void listFacilities() {
        System.out.println("\n-- Facilities --");
        for (Facility f : manager.listFacilities()) {
            System.out.println(f);
        }
    }

    private static void listUsers() {
        System.out.println("\n-- Registered Users --");
        for (User u : manager.listUsers()) {
            System.out.println(u + " | Priority:" + u.getBookingPriority());
        }
    }

    private static void bookFacilityMenu() throws InvalidBookingException, FacilityUnavailableException, DuplicateBookingException {
        System.out.print("User ID: ");
        String userId = sc.nextLine().trim();
        System.out.print("Facility ID: ");
        String facilityId = sc.nextLine().trim();
        System.out.print("Day (e.g. MON): ");
        String day = sc.nextLine().trim();
        System.out.print("Start hour (0-23): ");
        int start = Integer.parseInt(sc.nextLine().trim());
        System.out.print("End hour (0-23): ");
        int end = Integer.parseInt(sc.nextLine().trim());

        Booking b = manager.bookFacility(userId, facilityId, day, start, end);
        System.out.println("Booking confirmed: " + b);
    }

    private static void cancelBookingMenu() {
        System.out.print("Booking ID to cancel: ");
        String id = sc.nextLine().trim();
        boolean ok = manager.cancelBooking(id);
        System.out.println(ok ? "Booking cancelled." : "Booking not found / already inactive.");
    }

    private static void modifyBookingMenu() throws InvalidBookingException, FacilityUnavailableException, DuplicateBookingException {
        System.out.print("Booking ID to modify: ");
        String id = sc.nextLine().trim();
        System.out.print("New day: ");
        String day = sc.nextLine().trim();
        System.out.print("New start hour: ");
        int start = Integer.parseInt(sc.nextLine().trim());
        System.out.print("New end hour: ");
        int end = Integer.parseInt(sc.nextLine().trim());
        Booking b = manager.modifyBooking(id, day, start, end);
        System.out.println("Booking rescheduled: " + b);
    }

    private static void viewAllBookings() {
        System.out.println("\n-- All Bookings --");
        for (Booking b : manager.getAllBookings()) {
            System.out.println(b);
        }
    }

    private static void utilizationReport() {
        System.out.println("\n-- Facility Utilization Report (hours booked) --");
        for (Map.Entry<String, Integer> e : manager.generateUtilizationReport().entrySet()) {
            System.out.printf("%-20s : %d hour(s)%n", e.getKey(), e.getValue());
        }
    }

    private static void userActivityReport() {
        System.out.println("\n-- User Activity Report (confirmed bookings) --");
        for (Map.Entry<String, Long> e : manager.generateUserActivityReport().entrySet()) {
            System.out.printf("%-20s : %d booking(s)%n", e.getKey(), e.getValue());
        }
    }

    /**
     * Launches several threads that try to book overlapping/conflicting
     * slots simultaneously, proving synchronization prevents double-booking.
     */
    private static void runConcurrentDemo() throws InterruptedException {
        System.out.println("\n-- Concurrent Booking Demo --");
        List<Thread> threads = new ArrayList<>();
        threads.add(new Thread(new BookingWorker(manager, "U1", "F1", "WED", 10, 12), "Thread-Student"));
        threads.add(new Thread(new BookingWorker(manager, "U2", "F1", "WED", 11, 13), "Thread-Faculty"));
        threads.add(new Thread(new BookingWorker(manager, "U3", "F2", "WED", 9, 10), "Thread-Researcher"));
        threads.add(new Thread(new BookingWorker(manager, "U1", "F3", "THU", 14, 16), "Thread-Student2"));

        for (Thread t : threads) t.start();
        for (Thread t : threads) t.join(); // wait for all threads (inter-thread communication)

        System.out.println("Concurrent demo complete. See results above.");
    }

    /** Pre-loads a few users and facilities so the menu is usable immediately. */
    private static void seedDemoData() {
        manager.registerUser(new Student("U1", "Aditi Rao", "CSE"));
        manager.registerUser(new Faculty("U2", "Dr. Kumar", "ECE"));
        manager.registerUser(new Researcher("U3", "Dr. Meera", "AI Lab"));

        manager.addFacility(new ComputerLab("F1", "Lab-A", 60));
        manager.addFacility(new SeminarHall("F2", "Seminar Hall-1", 150));
        manager.addFacility(new MeetingRoom("F3", "Meeting Room-2", 12));
        manager.addFacility(new MultimediaStudio("F4", "Studio-1", 20));
        manager.addFacility(new InnovationCenter("F5", "Innovation Hub", 30));
    }
}
