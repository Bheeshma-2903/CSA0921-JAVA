package campus;

/** Thrown when the same user tries to book the same facility/slot twice. */
public class DuplicateBookingException extends Exception {
    public DuplicateBookingException(String message) {
        super(message);
    }
}
