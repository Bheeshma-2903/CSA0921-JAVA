package campus;

/**
 * Abstract base class representing any person who can use the
 * Smart Campus Resource Allocation system.
 * Demonstrates: Abstraction, Encapsulation (private fields + getters).
 */
public abstract class User {
    private final String userId;
    private final String name;
    private final String department;

    public User(String userId, String name, String department) {
        this.userId = userId;
        this.name = name;
        this.department = department;
    }

    public String getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }

    public String getDepartment() {
        return department;
    }

    /** Every concrete user type must describe its own role/privileges. */
    public abstract String getRole();

    /** Runtime polymorphism: booking priority differs by user type. */
    public abstract int getBookingPriority();

    @Override
    public String toString() {
        return String.format("[%s] %s (%s) - %s", userId, name, department, getRole());
    }
}
