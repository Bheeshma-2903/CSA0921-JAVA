package campus;

import java.util.*;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Core engine of the Smart Campus Resource Allocation system.
 *
 * Demonstrates:
 *  - Java Collection Framework: Map, List, generics, Iterator
 *  - Multithreading & synchronization (synchronized methods + explicit lock)
 *  - Custom exception handling
 */
public class BookingManager {

    // Map<facilityId, Facility>  -> quick lookup of resources
    private final Map<String, Facility> facilityMap = new HashMap<>();

    // Map<userId, User> -> registered users
    private final Map<String, User> userMap = new HashMap<>();

    // List<Booking> -> full booking history (chronological)
    private final List<Booking> bookings = Collections.synchronizedList(new ArrayList<>());

    // A lock dedicated to the "critical section" where availability is
    // checked and a new booking is committed, to avoid double-booking
    // when multiple threads (users) book concurrently.
    private final ReentrantLock bookingLock = new ReentrantLock();

    public void registerUser(User user) {
        userMap.put(user.getUserId(), user);
    }

    public void addFacility(Facility facility) {
        facilityMap.put(facility.getFacilityId(), facility);
    }

    public Collection<Facility> listFacilities() {
        return facilityMap.values();
    }

    public Collection<User> listUsers() {
        return userMap.values();
    }

    public Facility getFacility(String facilityId) throws InvalidBookingException {
        Facility f = facilityMap.get(facilityId);
        if (f == null) {
            throw new InvalidBookingException("No such facility: " + facilityId);
        }
        return f;
    }

    public User getUser(String userId) throws InvalidBookingException {
        User u = userMap.get(userId);
        if (u == null) {
            throw new InvalidBookingException("No such user: " + userId);
        }
        return u;
    }

    /**
     * Creates a booking after validating input and checking for clashes.
     * This is the method invoked concurrently by multiple booking threads,
     * so the check-then-act sequence is guarded by a lock to make it atomic.
     */
    public Booking bookFacility(String userId, String facilityId, String day, int startHour, int endHour)
            throws InvalidBookingException, FacilityUnavailableException, DuplicateBookingException {

        if (startHour < 0 || endHour > 23 || startHour >= endHour) {
            throw new InvalidBookingException("Invalid time range: " + startHour + "-" + endHour);
        }

        User user = getUser(userId);
        Facility facility = getFacility(facilityId);

        Booking candidate = new Booking(user, facility, day, startHour, endHour);

        bookingLock.lock();
        try {
            for (Booking existing : bookings) {
                if (!existing.getStatus().equals("CONFIRMED")) continue;

                if (existing.getUser().getUserId().equals(userId)
                        && existing.getFacility().getFacilityId().equals(facilityId)
                        && existing.getDay().equalsIgnoreCase(day)
                        && existing.getStartHour() == startHour
                        && existing.getEndHour() == endHour) {
                    throw new DuplicateBookingException(
                            "User " + userId + " already holds this exact booking (" + existing.getBookingId() + ")");
                }

                if (existing.overlaps(candidate)) {
                    throw new FacilityUnavailableException(
                            "Facility " + facilityId + " is already booked on " + day
                                    + " during " + existing.getStartHour() + "-" + existing.getEndHour()
                                    + " (" + existing.getBookingId() + ")");
                }
            }
            bookings.add(candidate);
            facility.addBookedHours(candidate.getDurationHours());
        } finally {
            bookingLock.unlock();
        }
        return candidate;
    }

    /** Cancels a booking by id. Synchronized so cancel/modify never race with booking checks. */
    public synchronized boolean cancelBooking(String bookingId) {
        for (Booking b : bookings) {
            if (b.getBookingId().equalsIgnoreCase(bookingId) && b.getStatus().equals("CONFIRMED")) {
                b.setStatus("CANCELLED");
                return true;
            }
        }
        return false;
    }

    /** Modifies (reschedules) a booking; internally cancels + re-books to reuse validation. */
    public Booking modifyBooking(String bookingId, String newDay, int newStart, int newEnd)
            throws InvalidBookingException, FacilityUnavailableException, DuplicateBookingException {
        Booking old = null;
        for (Booking b : bookings) {
            if (b.getBookingId().equalsIgnoreCase(bookingId) && b.getStatus().equals("CONFIRMED")) {
                old = b;
                break;
            }
        }
        if (old == null) {
            throw new InvalidBookingException("No active booking with id " + bookingId);
        }
        cancelBooking(bookingId);
        old.setStatus("MODIFIED");
        return bookFacility(old.getUser().getUserId(), old.getFacility().getFacilityId(), newDay, newStart, newEnd);
    }

    /** Returns a snapshot list of bookings, using an Iterator explicitly. */
    public List<Booking> getAllBookings() {
        List<Booking> snapshot = new ArrayList<>();
        synchronized (bookings) {
            Iterator<Booking> it = bookings.iterator();
            while (it.hasNext()) {
                snapshot.add(it.next());
            }
        }
        return snapshot;
    }

    /** Generates a simple utilization report: total booked hours per facility. */
    public Map<String, Integer> generateUtilizationReport() {
        Map<String, Integer> report = new TreeMap<>();
        for (Facility f : facilityMap.values()) {
            report.put(f.getName(), f.getTotalHoursBooked());
        }
        return report;
    }

    /** Booking count per user, demonstrating Map + generics based aggregation. */
    public Map<String, Long> generateUserActivityReport() {
        Map<String, Long> report = new TreeMap<>();
        for (Booking b : getAllBookings()) {
            if (!b.getStatus().equals("CONFIRMED")) continue;
            report.merge(b.getUser().getName(), 1L, Long::sum);
        }
        return report;
    }
}
