package campus;

/**
 * A Runnable task representing one user's concurrent attempt to
 * book a facility. Multiple BookingWorkers are launched as separate
 * Threads to demonstrate multithreading, synchronization and
 * inter-thread-safe exception handling within BookingManager.
 */
public class BookingWorker implements Runnable {
    private final BookingManager manager;
    private final String userId;
    private final String facilityId;
    private final String day;
    private final int startHour;
    private final int endHour;

    public BookingWorker(BookingManager manager, String userId, String facilityId,
                          String day, int startHour, int endHour) {
        this.manager = manager;
        this.userId = userId;
        this.facilityId = facilityId;
        this.day = day;
        this.startHour = startHour;
        this.endHour = endHour;
    }

    @Override
    public void run() {
        String threadName = Thread.currentThread().getName();
        try {
            Booking b = manager.bookFacility(userId, facilityId, day, startHour, endHour);
            System.out.println("[" + threadName + "] SUCCESS -> " + b);
        } catch (FacilityUnavailableException | DuplicateBookingException | InvalidBookingException e) {
            System.out.println("[" + threadName + "] FAILED  -> " + e.getMessage());
        }
    }
}
