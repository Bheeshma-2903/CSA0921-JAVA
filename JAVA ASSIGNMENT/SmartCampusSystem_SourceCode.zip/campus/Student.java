package campus;

/** Student user – lowest booking priority. */
public class Student extends User {
    public Student(String userId, String name, String department) {
        super(userId, name, department);
    }

    @Override
    public String getRole() {
        return "Student";
    }

    @Override
    public int getBookingPriority() {
        return 1;
    }
}
