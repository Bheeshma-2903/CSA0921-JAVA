package campus;

public class MultimediaStudio extends Facility {
    public MultimediaStudio(String facilityId, String name, int capacity) {
        super(facilityId, name, capacity);
    }

    @Override
    public String getFeatures() {
        return "Green screen, recording & editing rigs";
    }

    @Override
    public double getHourlyRate() {
        return 250.0;
    }
}
