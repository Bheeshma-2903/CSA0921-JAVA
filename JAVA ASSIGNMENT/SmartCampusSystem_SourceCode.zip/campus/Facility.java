package campus;

/**
 * Abstract base class for every bookable campus resource.
 * Demonstrates: Abstraction, Encapsulation.
 */
public abstract class Facility {
    private final String facilityId;
    private final String name;
    private final int capacity;
    private int totalHoursBooked; // used for utilization reports

    public Facility(String facilityId, String name, int capacity) {
        this.facilityId = facilityId;
        this.name = name;
        this.capacity = capacity;
        this.totalHoursBooked = 0;
    }

    public String getFacilityId() {
        return facilityId;
    }

    public String getName() {
        return name;
    }

    public int getCapacity() {
        return capacity;
    }

    public synchronized void addBookedHours(int hours) {
        this.totalHoursBooked += hours;
    }

    public synchronized int getTotalHoursBooked() {
        return totalHoursBooked;
    }

    /** Every facility type states the equipment/features it offers. */
    public abstract String getFeatures();

    /** Every facility type has its own hourly usage charge/points. */
    public abstract double getHourlyRate();

    @Override
    public String toString() {
        return String.format("[%s] %s (Capacity:%d) - %s | Rate:%.2f/hr | Booked so far:%dh",
                facilityId, name, capacity, getFeatures(), getHourlyRate(), totalHoursBooked);
    }
}
