package campus;

import java.util.Objects;

/**
 * Represents one reservation of a Facility by a User for a given
 * day and hour-slot range [startHour, endHour).
 */
public class Booking {
    private static int counter = 1000;

    private final String bookingId;
    private final User user;
    private final Facility facility;
    private final String day;      // e.g. "MON", "TUE" ...
    private final int startHour;   // 24-hour clock, e.g. 9
    private final int endHour;     // exclusive, e.g. 11
    private String status;         // CONFIRMED, CANCELLED, MODIFIED

    public Booking(User user, Facility facility, String day, int startHour, int endHour) {
        this.bookingId = "BK" + (++counter);
        this.user = user;
        this.facility = facility;
        this.day = day;
        this.startHour = startHour;
        this.endHour = endHour;
        this.status = "CONFIRMED";
    }

    public String getBookingId() {
        return bookingId;
    }

    public User getUser() {
        return user;
    }

    public Facility getFacility() {
        return facility;
    }

    public String getDay() {
        return day;
    }

    public int getStartHour() {
        return startHour;
    }

    public int getEndHour() {
        return endHour;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getDurationHours() {
        return endHour - startHour;
    }

    /** Two bookings clash if same facility, same day and overlapping hour range. */
    public boolean overlaps(Booking other) {
        if (!this.facility.getFacilityId().equals(other.facility.getFacilityId())) return false;
        if (!this.day.equalsIgnoreCase(other.day)) return false;
        return this.startHour < other.endHour && other.startHour < this.endHour;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Booking)) return false;
        Booking b = (Booking) o;
        return bookingId.equals(b.bookingId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(bookingId);
    }

    @Override
    public String toString() {
        return String.format("%s | %s booked %s on %s %02d:00-%02d:00 | %s",
                bookingId, user.getName(), facility.getName(), day, startHour, endHour, status);
    }
}
