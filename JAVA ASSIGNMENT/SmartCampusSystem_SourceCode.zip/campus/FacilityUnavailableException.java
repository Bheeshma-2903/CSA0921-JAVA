package campus;

/** Thrown when a facility is already booked for the requested slot. */
public class FacilityUnavailableException extends Exception {
    public FacilityUnavailableException(String message) {
        super(message);
    }
}
