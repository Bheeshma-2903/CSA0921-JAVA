package campus;

/** Thrown for structurally invalid booking requests (bad time range, unknown IDs, etc.). */
public class InvalidBookingException extends Exception {
    public InvalidBookingException(String message) {
        super(message);
    }
}
